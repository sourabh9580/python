import numpy as np

# Creating an array of integers
A = np.array([1, 2, 3, 4, 5])
B = np.array([6, 7, 8, 9, 10])

# Printing the array
print(A)

# printing an array element
print(B[3])

# Addition of two arrays
print(A+B)

# multiplication of two arrays
print(A*B)

# subtraction of two arrays
print(B-A)

# division of two arrays
print(B/A)
