# single input
A = input("Enter your name: ")
print("Hello ", A)

# Type casting
B = int(input("Enter your age: "))
print("Your age is ", B)

# Multiple inputs
C, D = input("Enter first number: "), input("Enter second number: ")
print("Sum of two numbers is ", int(C) + int(D))

# Evaluate expression
E = input("Enter expression: ")
print("Result of expression is ", eval(E))
