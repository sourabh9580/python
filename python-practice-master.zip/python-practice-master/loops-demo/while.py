# while loop
A = 0
while A < 10:
    print(A, end=' ')
    A += 1
