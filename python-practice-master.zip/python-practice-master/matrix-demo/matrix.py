import numpy as np

# Matrix of zeros
A = np.zeros((2, 3))

# A = np.ones((3, 3))

# Assign 1 to the first row and second column
# A[0, 1] = 1
# printing the matrix
print(A)

# printing the transpose of the matrix
# print(A.T)

# printing data type of the matrix
# print(A.dtype)

# multiplying the matrix by 3 and substrating 1
# print(3 * A - 1)

# printing second row and all columns
# print(A[1:])

# printing first and second row and all columns
# print(A[0:2])

# printing all rows and first and second column
# print(A[:, 0:2])
