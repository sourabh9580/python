A = int(input("Enter a number: "))

if A < 0:
    print("Negative")

elif A == 0:
    print("Zero")

elif A == 1:
    print("One")

else:
    print("Multiple")
