# iterate from 1 to 10 and print the sum of current number and previous number
for i in range(1, 11):
    print(i, "+", i-1, "=", i+i-1)