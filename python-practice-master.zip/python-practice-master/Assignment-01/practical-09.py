A = {'Yellow','Orange'}
B = ['Blue','Black']

# Adding list to set
print("The set is:", A)
print("The list is:", B)
print("--Adding list to set--")
C = A.union(B)
print("The set is:", C)