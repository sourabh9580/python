A = [10,20,30,40]

# Reversing the list using for loop
print("The list is:", A)
print("--Reversing the list using for loop--")
for i in range(len(A)-1,-1,-1):
    print(A[i],end=" ")